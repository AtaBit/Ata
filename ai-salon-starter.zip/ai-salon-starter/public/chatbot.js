(function(){
  const style = document.createElement('style');
  style.textContent = `
  .ai-bubble{position:fixed;right:20px;bottom:20px;border-radius:30px;padding:12px 16px;background:#111;color:#fff;cursor:pointer;font-weight:600;z-index:9999}
  .ai-panel{position:fixed;right:20px;bottom:70px;width:340px;max-height:60vh;background:#fff;border:1px solid #ddd;border-radius:12px;overflow:hidden;display:none;flex-direction:column;z-index:9999}
  .ai-header{padding:10px 12px;font-weight:700;border-bottom:1px solid #eee}
  .ai-msgs{padding:10px;overflow:auto;flex:1}
  .ai-input{display:flex;border-top:1px solid #eee}
  .ai-input input{flex:1;border:0;padding:10px}
  .ai-input button{border:0;padding:10px 12px;font-weight:600;cursor:pointer}
  `;
  document.head.appendChild(style);
  const bubble = document.createElement('div');
  bubble.className='ai-bubble';
  bubble.textContent='Friseur KI • Chat';
  const panel = document.createElement('div');
  panel.className='ai-panel';
  panel.innerHTML = `
    <div class="ai-header">Masterclass – KI Rezeption</div>
    <div class="ai-msgs"></div>
    <div class="ai-input">
      <input placeholder="Schreibe deine Nachricht..." />
      <button>Senden</button>
    </div>`;
  document.body.appendChild(bubble);
  document.body.appendChild(panel);
  const msgs = panel.querySelector('.ai-msgs');
  const input = panel.querySelector('input');
  const btn = panel.querySelector('button');
  const history = [];
  function add(role, text){
    const div = document.createElement('div');
    div.style.margin = '8px 0';
    div.innerHTML = `<b>${role==='user'?'Du':'KI'}:</b> ${text}`;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }
  bubble.onclick = ()=>{ panel.style.display = panel.style.display==='flex'?'none':'flex'; panel.style.flexDirection='column'; if(!panel.dataset.started){ add('assistant','Hallo! Ich bin die KI-Rezeption. Für welchen Standort (Ostermiething oder Mattighofen) und welchen Service darf ich einen Termin suchen?'); panel.dataset.started = '1'; } };
  async function send(){
    const text = input.value.trim();
    if(!text) return;
    add('user', text);
    input.value='';
    const r = await fetch('/api/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({history, message:text})});
    const data = await r.json();
    if(data.reply){
      history.push({role:'user', content:text});
      history.push({role:'assistant', content:data.reply});
      add('assistant', data.reply.replace(/\n/g,'<br>'));
    }else{
      add('assistant','(Fehler – bitte später erneut versuchen)');
    }
  }
  btn.onclick = send;
  input.addEventListener('keydown', e=>{ if(e.key==='Enter') send(); });
})();
