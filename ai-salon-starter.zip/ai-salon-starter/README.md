# AI Salon Starter – Weg 2 (Testversion)
Stand: 2025-12-13

Diese Testversion erlaubt es dir, die KI-Rezeption **sofort lokal zu testen** – ohne Programmieren.

## 1) Anforderungen
- Node.js 18+
- Ein OpenAI API Key

## 2) Installation
```bash
npm install
cp .env.example .env
# trage deinen OPENAI_API_KEY in .env ein
npm start
```
Öffne dann: **http://localhost:3000/test-chat**

## 3) WhatsApp (optional)
- Trage die WhatsApp Cloud API Daten in `.env` ein (PHONE_NUMBER_ID, TOKEN, VERIFY_TOKEN).
- Setze den Webhook bei Meta auf `https://DEINE-DOMAIN/webhook` (für lokal via ngrok).
- Die Logik ist als Stub vorbereitet (`/webhook`).

## 4) Termino/Termingo
Diese Testversion nutzt **Mock-Verfügbarkeiten**. Für Livebetrieb kannst du in `/api/checkAvailability` und `/api/createBooking`:
- deinen Kalender/DB anbinden oder
- auf die Buchungs-Links (Termingo) weiterleiten.

## 5) Website-Einbindung
Füge auf deiner Website (z. B. `<head>` oder vor `</body>`) ein:
```html
<script src="https://DEINE-DOMAIN/chatbot.js"></script>
```
Lokal für Tests ist die Bubble bereits auf **/test-chat** aktiv.

## 6) Konfiguration
- `config/salon.json`: Standorte, Öffnungszeiten, Dienste, Mitarbeiter
- `config/system_prompt.txt`: Verhalten & Regeln der KI

## 7) Hinweise
- Samstage sind als „by_appointment“ markiert – die KI soll dann auf Telefon hinweisen.
- Pufferzeiten: Standard 10 Minuten (Farbe 20 Minuten).
- Passe Services und Dauern jederzeit in `config/salon.json` an.
