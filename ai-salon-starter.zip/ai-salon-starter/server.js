import 'dotenv/config';
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import OpenAI from 'openai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Load config
const salon = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'salon.json'), 'utf-8'));
const systemPrompt = fs.readFileSync(path.join(__dirname, 'config', 'system_prompt.txt'), 'utf-8');

// ---- Mock availability (replace with real calendar or Termingo API integration) ----
function getMockSlots(serviceMinutes, dateIso){
  // generate 4 slots starting from 10:00 at every hour
  const date = new Date(dateIso);
  const base = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 10, 0, 0);
  const slots = [];
  for (let i=0;i<4;i++){
    const start = new Date(base.getTime() + i*60*60*1000);
    const end = new Date(start.getTime() + serviceMinutes*60*1000);
    slots.push({ start: start.toISOString(), end: end.toISOString() });
  }
  return slots;
}

// ---- API: checkAvailability ----
app.post('/api/checkAvailability', (req,res)=>{
  const { service, stylist, location, date } = req.body;
  const svc = salon.services.find(s=>s.name.toLowerCase() === String(service||'').toLowerCase());
  const minutes = svc ? svc.duration_min : 30;
  const slots = getMockSlots(minutes, date || new Date().toISOString());
  res.json({ ok:true, slots });
});

// ---- API: createBooking ----
app.post('/api/createBooking', (req,res)=>{
  const { name, phone, service, stylist, location, start } = req.body;
  // Here you would write to your DB or call Termingo if available
  const id = 'BKG-' + Date.now();
  res.json({ ok:true, bookingId:id, summary: { name, phone, service, stylist, location, start } });
});

// ---- Minimal chat endpoint (OpenAI) ----
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post('/api/chat', async (req,res)=>{
  const { history = [], message } = req.body;
  try{
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role:"system", content: systemPrompt },
        ...history,
        { role:"user", content: String(message||'') }
      ],
      temperature: 0.3
    });
    const reply = completion.choices[0].message.content;
    res.json({ ok:true, reply });
  }catch(e){
    console.error(e);
    res.status(500).json({ ok:false, error: e.message });
  }
});

// ---- WhatsApp webhook stubs (Cloud API) ----
app.get('/webhook', (req,res)=>{
  // verification
  if (req.query['hub.verify_token'] === process.env.WHATSAPP_VERIFY_TOKEN){
    return res.send(req.query['hub.challenge']);
  }
  res.sendStatus(403);
});

app.post('/webhook', (req,res)=>{
  // Here you would parse incoming WhatsApp messages and reply via Cloud API using fetch
  // This is a stub for quick start; details in README.
  res.sendStatus(200);
});

// ---- Serve a simple test chat page ----
app.get('/test-chat', (req,res)=>{
  res.sendFile(path.join(__dirname, 'public', 'test.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log(`AI Salon Starter läuft auf http://localhost:${PORT}`));
